HDClone 4.3 Professional Edition
================================


---PROGRAM STARTUP------------------------------------------

Run HDClone directly under Windows by starting HDCLONE.EXE.

The self-booting HDClone is operating system independent
and can be started by booting directly from this CD. 

For this purpose, insert this CD into a bootable drive
and restart the computer. Ensure in the BIOS that it
will boot from this drive. HDClone will then be loaded
automatically when starting the PC.

Further information about starting and operating HDClone
is to be found in the user's manual.



(c) 2002-13 by Miray Software
